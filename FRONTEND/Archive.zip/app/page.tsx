import FloatChat from "../components/float-chat"

export default function Home() {
  return <FloatChat />
}
