import InteractiveGlobe from "../../components/interactive-globe"

export default function GlobePage() {
  return (
    <div className="h-screen w-full">
      <InteractiveGlobe />
    </div>
  )
}
